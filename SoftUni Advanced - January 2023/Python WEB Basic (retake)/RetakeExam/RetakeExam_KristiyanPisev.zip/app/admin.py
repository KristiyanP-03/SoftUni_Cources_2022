from django.contrib import admin

from app.models import Profile

# Register your models here.
admin.site.register(Profile)

